import java.lang.*;
import java.util.*;
import java.io.*;

public class FCFS
{
	private int[] points;
	private int length;
	public FCFS(Process[] p){
		//
		this.length = p.size();


	}
	public void createQueue(){
		//
	}
	public int[] getPoints(){
		//
		return points;
	}
}